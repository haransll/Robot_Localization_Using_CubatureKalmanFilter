
fastslam2r_sim is a slight variation on the normal FastSLAM 2 algorithm. It incorporates "reverse resampling" by computing sample weights and resampling *before* the proposal distribution is obtained.
