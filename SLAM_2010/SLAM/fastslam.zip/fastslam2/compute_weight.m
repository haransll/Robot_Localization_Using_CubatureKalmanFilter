function w= compute_weight(particle, z, idf, R)

%%
%% Not used - weight is now computed within sample_proposal.m
%%